<?php

	FOREACH($_SERVER as $name => $val){
		echo '$_SERVER["'.$name . '"] .... <b style="color:crimson;">'. $val.'</b><br>';
	}

?>