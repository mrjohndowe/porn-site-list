porn-site-list
==============

List of porn sites on the world

This repository contains lists of porn sites in JSON.

Currently lists of site, scrapping from [theporndude.com](http://theporndude.com/) and [theporndude.com](http://mypornbible.com/)

I create this repo, because i want to list all (top) porn site, we when user submit link to your site, you cant check and prevent


### How to contribute?
- Just do [Pull request]https://github.com/aredo/porn-site-list/pulls and new site with JSON structure
```js
{
  "protocol": "http",
  "domain": "www.tube8.com",
  "path": null,
  "subdomain": "www",
  "host": "tube8",
  "tld": "com",
  "parent_domain": "tube8.com"
}
```
